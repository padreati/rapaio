package cern.colt.function.tdcomplex;

public interface DComplexDComplexRealRealFunction {
    abstract public double apply(double[] x, double[] y, double tol);
}
