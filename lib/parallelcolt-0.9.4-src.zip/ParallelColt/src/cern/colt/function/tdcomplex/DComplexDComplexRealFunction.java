package cern.colt.function.tdcomplex;

public interface DComplexDComplexRealFunction {
    abstract public double apply(double[] x, double[] y);
}
