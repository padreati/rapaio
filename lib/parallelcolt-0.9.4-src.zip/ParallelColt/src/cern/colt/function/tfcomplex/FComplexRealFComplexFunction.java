package cern.colt.function.tfcomplex;

public interface FComplexRealFComplexFunction {
    abstract public float[] apply(float[] x, float y);
}
