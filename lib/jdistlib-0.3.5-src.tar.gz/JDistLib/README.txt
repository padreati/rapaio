This program is a manual Java translation of R's distribution library
found in src/nmath folder of the source tar ball. The translation took
place from February 10, 2012 to February 12, 2012 and was based on
R version 2.14.1. The original code was in C, so the translation is
relatively straightforward, except in a few routines that are peppered
with gotos.

What distributions are included? Virtually all standard distribution
included in R. See the home page for details:
http://jdistlib.sf.net

Roby Joehanes
