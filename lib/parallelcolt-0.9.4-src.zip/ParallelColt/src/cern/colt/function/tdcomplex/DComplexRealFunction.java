package cern.colt.function.tdcomplex;

public interface DComplexRealFunction {
    abstract public double apply(double[] x);
}
